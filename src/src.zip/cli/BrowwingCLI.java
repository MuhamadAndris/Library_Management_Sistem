package src.cli;

import java.util.Arrays;
import java.util.List;

import src.util.ConsoleUtils;

public class BrowwingCLI {
    ConsoleUtils cUtils = new ConsoleUtils();
    private LibraryCLI libraryCLI;
    List<String> items = Arrays.asList("Pinjam Buku", "Kembalikan Buku", "kembali");

    public BrowwingCLI(LibraryCLI libraryCLI) {
        this.libraryCLI = libraryCLI;
    }

    public void manageBrowing() {
        cUtils.format_display("Transaksi Peminjaman", items);

        selectManageBrowwing(cUtils.input("Masukan pilihan > "));
    }

    public void selectManageBrowwing(String menu) {
        switch (menu) {
            case "1":
                break;
            
            case "2":
                break;

            case "3":
                libraryCLI.showMainMenu();
                break;
        
            default:
                break;
        }
    }
}
