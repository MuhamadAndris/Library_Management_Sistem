package src.cli;

import java.util.Arrays;
import java.util.List;
import src.service.BookService;
import src.util.ConsoleUtils;
import src.model.Book;

public class BookCLI {
    private LibraryCLI libraryCLI;
    BookService bookService = new BookService();
    ConsoleUtils cUtils = new ConsoleUtils();
    List<String> items = Arrays.asList("Lihat Daftar Buku", "Tambah Buku", "Cari Buku", "Kembali");

    public BookCLI(LibraryCLI libraryCLI) {
        this.libraryCLI = libraryCLI; // Simpan objek Library yang dikirim dari bookCLI
    }

    public void manageBooks() {
        cUtils.format_display("Manajemen Buku", items);
        selectManageBooks(cUtils.input("Masukan pilihan > "));
    }

    public void selectManageBooks(String menu) {
        switch (menu.trim()) {
            case "1": // Show All Books
                bookService.showAllBooks();
                cUtils.menu(items);
                selectManageBooks(cUtils.input("Masukan pilihan > "));
                break;

            case "2": // Add book
                bookService.addBook();
                cUtils.menu(items);
                selectManageBooks(cUtils.input("Enter options > "));

                break;

            case "3": // Search Book
                cUtils.header("Cari Buku");
                bookService.showBook(bookService.getBooks());
                List<Book> results = bookService.searchBook(cUtils.input("Masukan ID/Judul/Penulis/Tahun > "));
                cUtils.header("Cari Buku");
                bookService.showBook(results);
                if (results.size() == 1) {
                    List<String> sub_menu = Arrays.asList("Ubah", "Hapus", "Kembali");
                    cUtils.menu(sub_menu);
                    actionBook(cUtils.input("Masukan pilihan > "));
                } else {
                    cUtils.menu(items);
                    selectManageBooks(cUtils.input("Masukan pilihan > "));
                }
                break;

            case "4": // Back
                libraryCLI.showMainMenu();
                break;

            default:
                ConsoleUtils.clear_screen();
                cUtils.pauseEnter("Pilihan tidak tersedia, Tekan Enter untuk melanjutkan...");
                manageBooks();
                break;
        }
    }

    public void actionBook(String menu) {
        switch (menu) {
            case "1" : // Edit
                if (bookService.editBook()) {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Data Buku berhasil diubah");
                    selectManageBooks("1");
                } else {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Data Buku Gagal diubah");
                    selectManageBooks("1");
                }
                break;
            case "2": // Delete
                if (bookService.deleteBook()) {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Buku berhasil dihapus");
                    selectManageBooks("1");
                } else {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Buku gagal dihapus");
                    selectManageBooks("1");
                }
                break;
            case "3": // Back
                manageBooks();
                break;
            default:
                cUtils.pauseEnter("Pilihan tidak tersedia, Tekan Enter untuk melanjutkan...");
                actionBook(cUtils.input("Masukan pilihan > "));
                break;
        }
    }
}
