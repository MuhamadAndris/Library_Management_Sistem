package src.cli;

import java.util.Arrays;
import java.util.List;

import src.model.Library;
import src.model.User;
import src.service.UserService;
import src.util.ConsoleUtils;

public class UsersCLI {
    private LibraryCLI libraryCLI;
    ConsoleUtils cUtils = new ConsoleUtils();
    Library moLibrary = new Library();
    UserService userService = new UserService();
    List<String> items = Arrays.asList("Lihat Daftar Anggota", "Tambah Anggota", "Cari Anggota", "Kembali");

    public UsersCLI(LibraryCLI libraryCLI) {
        this.libraryCLI = libraryCLI;   // Simpan objek libraryCLI
    }

    public void manageUsers() {
        cUtils.format_display("Manajemen Anggota", items);

        selectManageUsers(cUtils.input("Masukan pilihan > "));
    }

    public void selectManageUsers(String menu) {
        switch (menu.trim()) {
            case "1": // Show All Users
                cUtils.header("Daftar Anggota");
                // cUtils.showAllUsers(moLibrary.getUsers());
                userService.showUsers();

                cUtils.menu(items);
                selectManageUsers(cUtils.input("Masukan Pilihan > "));
                break;
            
            case "2": // Add user
                if (userService.addUser()) {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Anggota berhasil ditambahkan");
                    selectManageUsers("1");
                } else {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Anggota gagal ditambahkan");
                    selectManageUsers("1");
                }
                break;
            
            case "3": // Search User
                cUtils.header("Cari Anggota");
                userService.showUsers();
                List<User> results = userService.searchUser(cUtils.input("Masukan ID/Nama/Alamat > "));
                cUtils.header("Cari Anggota");
                userService.showUsers(results);
                if (results.size() == 1) {
                    List<String> sub_menu = Arrays.asList("Ubah", "Hapus", "kembali");
                    cUtils.menu(sub_menu);
                    actionUser(cUtils.input("Masukan pilihan > "));
                } else {
                    cUtils.menu(items);
                    selectManageUsers(cUtils.input("Masukan pilihan > "));
                }
                break;
            
            case "4": // Back
                libraryCLI.showMainMenu();
                break;

            default:
                ConsoleUtils.clear_screen();
                cUtils.pauseEnter("Pilihan tidak tersedia, Tekan Enter untuk melanjutkan...");
                manageUsers();
                break;
        }
    }

    public void actionUser(String menu) {
        switch (menu) {
            case "1" : // Edit
                if (userService.editUser()) {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Buku berhasil diubah");
                    selectManageUsers("1");
                } else {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Buku gagal diubah");
                    selectManageUsers("1");
                }
                break;
            case "2": // Delete
                if (userService.deleteUser()) {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Buku berhasil dihapus");
                    selectManageUsers("1");
                } else {
                    ConsoleUtils.clear_screen();
                    cUtils.pauseEnter("Buku gagal dihapus");
                    selectManageUsers("1");
                }
                break;
            case "3": // Back
                manageUsers();
                break;
            default:
                cUtils.pauseEnter("Pilihan tidak tersedia, Tekan Enter untuk melanjutkan...");
                actionUser(cUtils.input("Masukan pilihan > "));
                break;
        }
    }
}
