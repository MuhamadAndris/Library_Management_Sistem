package src;
import java.util.Scanner;
import src.cli.LibraryCLI;
import src.cli.LoginCLI;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LoginCLI loginCLI = new LoginCLI();

        LibraryCLI cliLibrary = new LibraryCLI();

        while (true) {
            Boolean status = loginCLI.login();
            if (status) {
                break;
                // tugas selanjutnya menambahkan database h2 untuk penyimpanan akunnya
            }
        }

        cliLibrary.showMainMenu();
        
        scanner.close();
    }

}
