package src.model;

public class Library {
    private String title = "LIBRARY MANAGEMENT SYSTEM";
    private int width = 100;

    // Getter dan Setter
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

}
